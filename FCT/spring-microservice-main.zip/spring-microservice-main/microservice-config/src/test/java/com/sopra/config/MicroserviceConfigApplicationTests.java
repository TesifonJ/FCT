package com.sopra.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
