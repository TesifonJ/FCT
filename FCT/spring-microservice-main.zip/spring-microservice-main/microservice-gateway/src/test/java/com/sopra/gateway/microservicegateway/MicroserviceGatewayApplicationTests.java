package com.sopra.gateway.microservicegateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
