package com.sopra.producttype.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.sopra.producttype.dto.ProductDto;

@FeignClient(name = "msvc-product", url = "localhost:8080/api/product")
public interface iProductTypeClient {

    @GetMapping("/search-by-product-type/{idProductType}")
    List<ProductDto> findAllProductByType();
}
