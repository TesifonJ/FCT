package com.sopra.producttype.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sopra.producttype.entities.ProductTypeEntity;

public interface iProductTypeDao extends JpaRepository<ProductTypeEntity, Long>{
    
}
