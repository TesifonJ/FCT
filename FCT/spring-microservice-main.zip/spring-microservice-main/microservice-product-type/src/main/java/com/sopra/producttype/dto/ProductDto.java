package com.sopra.producttype.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

public class ProductDto {
    private Long id;

    @NotNull
    @Size(min = 3, max = 255)
    private String name;

    @NotNull
    @Size(min = 3, max = 255)
    private String description;

    @DecimalMax(value = "99999999.99", message = "The price value must contain only two decimal")
    @PositiveOrZero
    private float price;

    private Long productTypeId;
    private String productTypeName;

    @PositiveOrZero
    private Long stock;

    public ProductDto() {
    }

    @Override
    public String toString() {
        return "{" +
                "id=" + getId() +
                ",name='" + getName() + "'" +
                ",description='" + getDescription() + "'" +
                ",price=" + getPrice() +
                ",productTypeId=" + getProductTypeId() +
                ",productTypeName='" + getProductTypeName() + "'" +
                ",stock=" + getStock() +
                "}";
    }

    public static class Builder {
        private ProductDto buildObj = new ProductDto();

        public Builder id(Long id) {
            buildObj.id = id;
            return this;
        }

        public Builder name(String name) {
            buildObj.name = name;
            return this;
        }

        public Builder description(String description) {
            buildObj.description = description;
            return this;
        }

        public Builder price(float price) {
            buildObj.price = price;
            return this;
        }

        public Builder productTypeId(Long productTypeId) {
            buildObj.productTypeId = productTypeId;
            return this;
        }

        public Builder productTypeName(String productTypeName) {
            buildObj.productTypeName = productTypeName;
            return this;
        }

        public Builder stock(Long stock) {
            buildObj.stock = stock;
            return this;
        }

        public ProductDto build() {
            return buildObj;
        }
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return this.id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return this.description;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getPrice() {
        return this.price;
    }

    public void setProductTypeId(Long productTypeId) {
        this.productTypeId = productTypeId;
    }

    public Long getProductTypeId() {
        return this.productTypeId;
    }

    public void setProductTypeName(String productTypeName) {
        this.productTypeName = productTypeName;
    }

    public String getProductTypeName() {
        return this.productTypeName;
    }

    public void setStock(Long stock) {
        this.stock = stock;
    }

    public Long getStock() {
        return this.stock;
    }
}
