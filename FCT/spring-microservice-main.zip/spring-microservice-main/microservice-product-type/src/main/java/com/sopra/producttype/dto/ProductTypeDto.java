package com.sopra.producttype.dto;

import java.util.List;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ProductTypeDto {
    private Long id;

    @NotBlank
    @NotNull
    private String productTypeName;

    private List<ProductTypeDto> products;

    public ProductTypeDto() {
    }

    @Override
    public String toString() {
        return "{" +
                "id=" + getId() +
                ",productTypeName='" + getProductTypeName() + "'" +
                ",products=" + getProducts() +
                "}";
    }

    public static class Builder {
        private ProductTypeDto buildObj = new ProductTypeDto();

        public Builder id(Long id) {
            buildObj.id = id;
            return this;
        }

        public Builder productTypeName(String productTypeName) {
            buildObj.productTypeName = productTypeName;
            return this;
        }

        public Builder products(List<ProductTypeDto> products) {
            buildObj.products = products;
            return this;
        }

        public ProductTypeDto build() {
            return buildObj;
        }
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return this.id;
    }

    public void setProductTypeName(String productTypeName) {
        this.productTypeName = productTypeName;
    }

    public String getProductTypeName() {
        return this.productTypeName;
    }

    public void setProducts(List<ProductTypeDto> products) {
        this.products = products;
    }

    public List<ProductTypeDto> getProducts() {
        return this.products;
    }
}
