package com.sopra.producttype.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "products")
public class ProductEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "PRODUCT_NAME", length = 50, nullable = false)
    String name;

    @Column(name = "PRODUCT_DESCRIPTION", length = 100)
    String description;

    @Column(name = "PRODUCT_PRICE")
    private float price;

    @ManyToOne
    @JoinColumn(name = "type_id")
    private ProductTypeEntity type;

    @Column(name = "PRODUCT_STOCK")
    private Long stock;

    public ProductEntity() {
    }

    public ProductEntity(Long id, String name, String description, float price, ProductTypeEntity type, Long stock) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.type = type;
        this.stock = stock;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return this.id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return this.description;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getPrice() {
        return this.price;
    }

    public void setType(ProductTypeEntity type) {
        this.type = type;
    }

    public ProductTypeEntity getType() {
        return this.type;
    }

    public void setStock(Long stock) {
        this.stock = stock;
    }

    public Long getStock() {
        return this.stock;
    }
}
