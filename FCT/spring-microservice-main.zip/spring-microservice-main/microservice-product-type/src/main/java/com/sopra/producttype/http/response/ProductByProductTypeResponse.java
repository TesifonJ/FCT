package com.sopra.producttype.http.response;

import java.util.List;

import com.sopra.producttype.dto.ProductDto;
import java.util.Objects;

public class ProductByProductTypeResponse {
    private String productTypeName;
    private List<ProductDto> productsDtoList;

    public ProductByProductTypeResponse() {
    }

    public ProductByProductTypeResponse(String productTypeName, List<ProductDto> productsDtoList) {
        this.productTypeName = productTypeName;
        this.productsDtoList = productsDtoList;
    }

    public String getProductTypeName() {
        return this.productTypeName;
    }

    public void setProductTypeName(String productTypeName) {
        this.productTypeName = productTypeName;
    }

    public List<ProductDto> getProductsDtoList() {
        return this.productsDtoList;
    }

    public void setProductsDtoList(List<ProductDto> productsDtoList) {
        this.productsDtoList = productsDtoList;
    }

    public ProductByProductTypeResponse productTypeName(String productTypeName) {
        setProductTypeName(productTypeName);
        return this;
    }

    public ProductByProductTypeResponse productsDtoList(List<ProductDto> productsDtoList) {
        setProductsDtoList(productsDtoList);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof ProductByProductTypeResponse)) {
            return false;
        }
        ProductByProductTypeResponse productByProductTypeResponse = (ProductByProductTypeResponse) o;
        return Objects.equals(productTypeName, productByProductTypeResponse.productTypeName)
                && Objects.equals(productsDtoList, productByProductTypeResponse.productsDtoList);
    }

    @Override
    public int hashCode() {
        return Objects.hash(productTypeName, productsDtoList);
    }

    @Override
    public String toString() {
        return "{" +
                " productTypeName='" + getProductTypeName() + "'" +
                ", productsDtoList='" + getProductsDtoList() + "'" +
                "}";
    }

    public static class Builder {
        private ProductByProductTypeResponse buildObj = new ProductByProductTypeResponse();

        public Builder productTypeName(String productTypeName) {
            buildObj.productTypeName = productTypeName;
            return this;
        }

        public Builder productsDtoList(List<ProductDto> productsDtoList) {
            buildObj.productsDtoList = productsDtoList;
            return this;
        }

        public ProductByProductTypeResponse build() {
            return buildObj;
        }
    }

}
