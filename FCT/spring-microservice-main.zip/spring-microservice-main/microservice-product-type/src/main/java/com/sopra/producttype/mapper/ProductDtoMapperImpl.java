package com.sopra.producttype.mapper;

import java.util.List;
import java.util.stream.Collectors;

import com.sopra.producttype.dto.ProductDto;
import com.sopra.producttype.entities.ProductEntity;
import com.sopra.producttype.entities.ProductTypeEntity;

public class ProductDtoMapperImpl implements iProductDtoMapper {

    @Override
    public ProductDto toProductDTO(ProductEntity productEntity) {
        ProductDto productDto = new ProductDto();

        if (productEntity.getId() != null) {
            productDto.setId(productEntity.getId());
        }
        productDto.setName(productEntity.getName());
        productDto.setDescription(productEntity.getDescription());
        productDto.setPrice(productEntity.getPrice());
        productDto.setStock(productEntity.getStock());
        if (productEntity.getType() != null) {
            productDto.setProductTypeId(productEntity.getType().getId());
            productDto.setProductTypeName(productEntity.getType().getName());
        }
        return productDto;
    }

    @Override
    public List<ProductDto> toProductsDTO(List<ProductEntity> productEntities) {
        return productEntities.stream()
                .map(productEntity -> toProductDTO(productEntity))
                .collect(Collectors.toList());
    }

    @Override
    public ProductEntity toProductEntity(ProductDto productDTO) {
        ProductEntity productEntity = new ProductEntity();

        if (productDTO.getId() != null) {
            productEntity.setId(productDTO.getId());
        }

        productEntity.setName(productDTO.getName());
        productEntity.setDescription(productDTO.getDescription());
        productEntity.setPrice(productDTO.getPrice());
        productEntity.setStock(productDTO.getStock());

        if (productDTO.getProductTypeId() != null) {
            productEntity
                    .setType(new ProductTypeEntity(productDTO.getProductTypeId(), productDTO.getProductTypeName()));
        }
        return productEntity;
    }

    @Override
    public List<ProductEntity> toProductEntities(List<ProductDto> productsDto) {
        return productsDto.stream()
                .map(productDto -> toProductEntity(productDto))
                .collect(Collectors.toList());
    }
}
