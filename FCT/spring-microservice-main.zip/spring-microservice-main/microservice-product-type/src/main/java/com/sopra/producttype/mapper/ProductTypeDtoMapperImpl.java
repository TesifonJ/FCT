package com.sopra.producttype.mapper;

import java.util.List;
import java.util.stream.Collectors;

import com.sopra.producttype.dto.ProductTypeDto;
import com.sopra.producttype.entities.ProductTypeEntity;

public class ProductTypeDtoMapperImpl implements iProductTypeDtoMapper {
    @Override
    public ProductTypeDto toProductTypeDTO(ProductTypeEntity productEntity) {
        ProductTypeDto productTypeDto = new ProductTypeDto();

        if (productEntity.getId() != null) {
            productTypeDto.setId(productEntity.getId());
        }
        productTypeDto.setProductTypeName(productEntity.getName());

        return productTypeDto;
    }

    @Override
    public List<ProductTypeDto> toProductTypesDTO(List<ProductTypeEntity> productTypeEntities) {
        return productTypeEntities.stream()
                .map(productTypeEntity -> toProductTypeDTO(productTypeEntity))
                .collect(Collectors.toList());
    }

    @Override
    public ProductTypeEntity toProductTypeEntity(ProductTypeDto productTypeDTO) {
        ProductTypeEntity productEntity = new ProductTypeEntity();

        if (productTypeDTO.getId() != null) {
            productEntity.setId(productTypeDTO.getId());
        }

        productEntity.setName(productTypeDTO.getProductTypeName());

        return productEntity;
    }

}
