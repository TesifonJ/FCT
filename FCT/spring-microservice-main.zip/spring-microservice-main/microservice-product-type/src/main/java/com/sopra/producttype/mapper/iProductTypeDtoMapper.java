package com.sopra.producttype.mapper;

import java.util.List;

import com.sopra.producttype.dto.ProductTypeDto;
import com.sopra.producttype.entities.ProductTypeEntity;

public interface iProductTypeDtoMapper {
    ProductTypeDto toProductTypeDTO(ProductTypeEntity productEntity);

    List<ProductTypeDto> toProductTypesDTO(List<ProductTypeEntity> productEntity);

    ProductTypeEntity toProductTypeEntity(ProductTypeDto productDTO);
}
