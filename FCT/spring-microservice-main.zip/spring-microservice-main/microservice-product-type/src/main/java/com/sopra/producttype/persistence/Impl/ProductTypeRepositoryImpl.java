package com.sopra.producttype.persistence.Impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.sopra.producttype.client.iProductTypeClient;
import com.sopra.producttype.dao.iProductTypeDao;
import com.sopra.producttype.dto.ProductDto;
import com.sopra.producttype.dto.ProductTypeDto;
import com.sopra.producttype.entities.ProductTypeEntity;
import com.sopra.producttype.http.response.ProductByProductTypeResponse;
import com.sopra.producttype.mapper.ProductTypeDtoMapperImpl;
import com.sopra.producttype.persistence.iProductTypeRepository;

import jakarta.persistence.EntityNotFoundException;

public class ProductTypeRepositoryImpl implements iProductTypeRepository {

    private iProductTypeDao oIProductTypeDao;
    private iProductTypeClient oProductTypeClient;

    @Override
    public List<ProductTypeDto> getProductTypes() {
        List<ProductTypeEntity> dataBaseTypes = oIProductTypeDao.findAll();
        List<ProductTypeDto> dtoTypes = new ArrayList<ProductTypeDto>();
        ProductTypeDtoMapperImpl oDtoMapperImpl = new ProductTypeDtoMapperImpl();

        for (ProductTypeEntity TypeEntity : dataBaseTypes) {
            dtoTypes.add(oDtoMapperImpl.toProductTypeDTO(TypeEntity));
        }
        return dtoTypes;
    }

    @Override
    public Optional<ProductTypeDto> findById(Long id) throws EntityNotFoundException{
        ProductTypeDtoMapperImpl oDtoMapperImpl = new ProductTypeDtoMapperImpl();

        ProductTypeEntity dataBaseType = oIProductTypeDao.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Product Type " + id + " not found"));
        return Optional.of(oDtoMapperImpl.toProductTypeDTO(dataBaseType));
    }

    @Override
    public ProductTypeDto saveProductType(ProductTypeDto productType) {
        ProductTypeDtoMapperImpl oDtoMapperImpl = new ProductTypeDtoMapperImpl();

        ProductTypeEntity newTypeEntity = oDtoMapperImpl.toProductTypeEntity(productType);
        oIProductTypeDao.saveAndFlush(newTypeEntity);

        return oDtoMapperImpl.toProductTypeDTO(newTypeEntity);
    }

    @Override
    public Long deleteProductTypeById(Long id) {
        ProductTypeEntity TypeEntity = oIProductTypeDao.findById(id).orElseThrow(
                () -> new EntityNotFoundException("Product Type " + id + " not found"));
        oIProductTypeDao.deleteById(TypeEntity.getId());
        return TypeEntity.getId();
    }

    public ProductByProductTypeResponse findProductsByProductTypeResponse(Long idProduct) {
        ProductTypeDto productFromDb = findById(idProduct).get();
        List<ProductDto> productDtoListFromDb = oProductTypeClient.findAllProductByType();

        ProductByProductTypeResponse productByProductTypeResponse = new ProductByProductTypeResponse.Builder()
                .productTypeName(productFromDb.getProductTypeName())
                .productsDtoList(productDtoListFromDb)
                .build();
        return productByProductTypeResponse;
    }

}
