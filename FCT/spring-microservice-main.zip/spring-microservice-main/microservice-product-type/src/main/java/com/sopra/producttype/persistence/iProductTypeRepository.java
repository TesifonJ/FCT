package com.sopra.producttype.persistence;

import java.util.List;
import java.util.Optional;

import com.sopra.producttype.dto.ProductTypeDto;

public interface iProductTypeRepository {
    List<ProductTypeDto> getProductTypes();

    Optional<ProductTypeDto> findById(Long id);

    ProductTypeDto saveProductType(ProductTypeDto productType);

    Long deleteProductTypeById(Long id);
}
