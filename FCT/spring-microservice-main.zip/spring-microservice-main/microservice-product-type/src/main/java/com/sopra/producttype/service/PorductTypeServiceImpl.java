package com.sopra.producttype.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.sopra.producttype.dto.ProductTypeDto;
import com.sopra.producttype.http.response.ProductByProductTypeResponse;
import com.sopra.producttype.persistence.Impl.ProductTypeRepositoryImpl;

public class PorductTypeServiceImpl implements iProductTypeService {

    private ProductTypeRepositoryImpl oProductTypeRepositoryImpl;

    @Autowired
    public PorductTypeServiceImpl(ProductTypeRepositoryImpl oProductTypeRepositoryImpl) {
        this.oProductTypeRepositoryImpl = oProductTypeRepositoryImpl;
    }

    @Override
    public List<ProductTypeDto> findAll() {
        return this.oProductTypeRepositoryImpl.getProductTypes();
    }

    @Override
    public ProductTypeDto findById(Long idProductType) {
        return this.oProductTypeRepositoryImpl.findById(idProductType).get();

    }

    @Override
    public ProductTypeDto save(ProductTypeDto productTypeDto) {
        return this.oProductTypeRepositoryImpl.saveProductType(productTypeDto);
    }

    @Override
    public ProductByProductTypeResponse findProductsByProductTypeResponse(Long idProduct) {
        return this.oProductTypeRepositoryImpl.findProductsByProductTypeResponse(idProduct);
    }

}
