package com.sopra.producttype.service;

import java.util.List;

import com.sopra.producttype.dto.ProductTypeDto;
import com.sopra.producttype.http.response.ProductByProductTypeResponse;

public interface iProductTypeService {
    List<ProductTypeDto> findAll();

    ProductTypeDto findById(Long id);

    ProductTypeDto save(ProductTypeDto productTypeDto);

    ProductByProductTypeResponse findProductsByProductTypeResponse(Long idProduct);
}
