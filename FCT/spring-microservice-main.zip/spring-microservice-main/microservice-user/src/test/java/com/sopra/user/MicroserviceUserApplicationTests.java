package com.sopra.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
