package com.sopra.apirestcontroller.controller.model;

public class ProductModel {

}
