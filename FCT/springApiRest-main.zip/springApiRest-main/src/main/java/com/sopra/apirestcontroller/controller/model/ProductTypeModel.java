package com.sopra.apirestcontroller.controller.model;

public class ProductTypeModel {
    //TO-DO
}
