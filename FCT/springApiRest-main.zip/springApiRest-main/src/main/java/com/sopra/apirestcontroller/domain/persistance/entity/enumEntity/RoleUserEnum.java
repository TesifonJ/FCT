package com.sopra.apirestcontroller.domain.persistance.entity.enumEntity;

public enum RoleUserEnum {
    ADMIN,
    USER
}
