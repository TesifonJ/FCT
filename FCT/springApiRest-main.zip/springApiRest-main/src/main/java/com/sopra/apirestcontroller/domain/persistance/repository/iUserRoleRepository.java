package com.sopra.apirestcontroller.domain.persistance.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface iUserRoleRepository {
    

}
