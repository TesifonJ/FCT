package com.sopra.apirestcontroller.repositoryImplTest;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProductTypeRepositoryImplTest {

}
